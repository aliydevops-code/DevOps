# VPN Manager — Ansible Setup

## راه‌اندازی سرور جدید با یه دستور

### ۱. نصب Ansible (یه بار، روی لپ‌تاپ/PC خودت)

```bash
pip install ansible
```

### ۲. تنظیم فایل‌های کانفیگ

**فقط دو فایل رو عوض کن:**

#### `inventory/hosts` — آدرس سرور جدید:
```ini
[vpn_servers]
node0 ansible_host=IP_سرور_جدید ansible_user=root
```

#### `group_vars/all.yml` — توکن بات و اطلاعات:
```yaml
bot_token: "توکن_بات_تلگرام"
admin_id: آیدی_عددی_ادمین
server_ip: "IP_سرور"
payment_card: "شماره_کارت"
payment_owner: "نام_صاحب_کارت"
```

### ۳. اجرا — همین یه خط کافیه!

```bash
ansible-playbook -i inventory/hosts site.yml
```

---

## دستورات بعد از نصب

### چک کردن وضعیت سرویس‌ها روی سرور:
```bash
systemctl status vpn-manager
systemctl status telegram-bot
systemctl status nginx
```

### لاگ‌ها:
```bash
journalctl -u telegram-bot -f
journalctl -u vpn-manager -f
```

### آپدیت بعد از تغییر کانفیگ:
```bash
ansible-playbook -i inventory/hosts site.yml --tags deploy
```

---

## ساختار فایل‌ها

```
vpn-ansible/
├── site.yml                    ← playbook اصلی
├── inventory/
│   └── hosts                   ← لیست سرورها
├── group_vars/
│   └── all.yml                 ← همه تنظیمات
└── roles/
    ├── common/                 ← apt, docker, ufw
    ├── xray/                   ← xray binary + nginx config
    ├── vpn-manager/            ← manager.py + systemd
    ├── nginx/                  ← فعال‌سازی nginx
    └── telegram-bot/           ← bot.py + systemd
```

---

## باگ‌فیکس‌های اعمال‌شده

| مشکل | وضعیت |
|------|--------|
| `restart-vpn-bot.sh` هر ۳۰ ثانیه ریست می‌کرد | ✅ حذف + سرویس درست جایگزین شد |
| `used_bytes` هر بار چندبرابر می‌شد | ✅ delta method جایگزین cumulative شد |
| کاربر لینک ساب نداشت | ✅ `/sub/{name}` endpoint اضافه شد |
| هدر `subscription-userinfo` نبود | ✅ اضافه شد (v2rayNG/Hiddify پشتیبانی می‌کنن) |
